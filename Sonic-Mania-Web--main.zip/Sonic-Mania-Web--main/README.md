# Sonic-Mania-Web-
MAIN MENU CRASHES! Press (Esc) to use Dev Menu to access levels. 


A web port of the 2017 video game, Sonic Mania, along with it's dlc.
